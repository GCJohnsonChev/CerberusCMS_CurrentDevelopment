<?php
/*
 ============================================================================================================
 + Cerberus Content Management System
 + ---
 + - Author 		     : Gary Christopher Johnson - Rosedale, California
 + - Electronic Mail Address : TinkeSoftware@Protonmail.com
 + - Company		     : Tinke Software
 + - Company Address	     : Rosedale, California, U.S.A.
 + - Document Notes	     : View this file in a non-formatting text editor without word-wrap for the correct
 +			       display of this programming code and its indentation.
 + ---
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 + ---
 + - File Location: root->Cerberus->System->Configuration->Global_SQL_Server_Configuration.php
 + - File Version : 0.6 - Wednesday, March 1st of 2023
 + ---
 + -------------------------------------------------------------------------------
 + --()()--()()()--()()()--()()()---()()()--()()()--()--()------()()()------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()()()--()()()--()()()---()()()--()()()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------/-\-
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------|4|-  ~ Wynn ~
 + --()()--()()()--()--()--()()()---()()()--()--()--()()()--()()()------------\-/- Build: 0.8
 ============================================================================================================
*/

/*
 ================================================================
 +
 +
 + Cerberus :: System Configuration :: Global S.Q.L. Server Configuration
 +
 +
 ================================================================
*/

$_ACCESS_SYSTEM_ELECTRONIC_MAIL_ADDRESS			= "";
$_ACCESS_DATABASE_SERVER_HOSTNAME			= "";
$_ACCESS_DATABASE_SERVER_USERNAME			= "";
$_ACCESS_DATABASE_SERVER_PASSWORD			= "";
$_ACCESS_DATABASE_SERVER_DATABASE_NAME			= "";
$_ACCESS_DATABASE_SERVER_DATABASE_TABLE_PREFIX		= "";
$_ACCESS_URL_CLEARTEXT					= "";
$_ACCESS_URL_SECURE					= "";
?>