/*
 ===========================================================================================
 + Cerberus Content Management System.
 + ---
 + - Author : Gary Christopher Johnson
 + - E-Mail : TinkeSoftware@Protonmail.com
 + - Company: Tinke Software
 + - Notes  : View this file in a non-formatting text editor for correct indentation display
 + ---
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 + ---
 + - File Location: root->Cerberus->License.txt
 + - File Version:  0.6 - Wednesday, March 1st of 2023.
 + ---
 + -------------------------------------------------------------------------------
 + --()()--()()()--()()()--()()()---()()()--()()()--()--()------()()()------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()()()--()()()--()()()---()()()--()()()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------/-\-
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------|4|-  ~ Wynn ~
 + --()()--()()()--()--()--()()()---()()()--()--()--()()()--()()()------------\-/- Build: 0.8
 ===========================================================================================
*/

================================
Installation Instructions
================================

https://www.SourceForge.net/projects/cerberuscms/Documentation
https://www.GitHub.com/TinkeSoftware/CerberusCMS_Documentation

================================
CerberusCMS on Source Forge
================================

https://www.SourceForge.net/projects/cerberuscms/

================================
CerberusCMS on Source Forge ( Demonstration Server )
================================

http://CerberusCMS.SourceForge.net

================================
CerberusCMS on Git Hub
================================

https://www.GitHub.com/TinkeSoftware/CerberusCMS

================================
CerberusCMS on Bit Bucket
================================

https://www.BitBucket.org/TinkeSoftware/CerberusCMS